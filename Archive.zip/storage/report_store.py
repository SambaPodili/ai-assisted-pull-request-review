"""
storage/report_store.py
------------------------
Stores and retrieves AnalysisReport objects.

Two backends:
  • InMemoryReportStore  — Phase 1/2, testing (lost on restart)
  • RedisReportStore     — Phase 3, production (persistent, TTL-based)
"""
from __future__ import annotations
import json
import logging
from datetime import datetime
from typing import Protocol, runtime_checkable

from core.models import AnalysisReport

log = logging.getLogger(__name__)
DEFAULT_TTL = 60 * 60 * 24 * 7   # 7 days

try:
    import redis as redis_client
    HAS_REDIS = True
except ImportError:
    HAS_REDIS = False


@runtime_checkable
class ReportStore(Protocol):
    def save(self, report: AnalysisReport) -> None: ...
    def get(self, request_id: str) -> AnalysisReport | None: ...
    def delete(self, request_id: str) -> bool: ...
    def list_recent(self, limit: int = 20) -> list[dict]: ...


# ── In-memory backend ─────────────────────────────────────────────────────────

class InMemoryReportStore:

    def __init__(self, max_size: int = 500) -> None:
        self._store:    dict[str, AnalysisReport] = {}
        self._order:    list[str] = []
        self._max_size  = max_size

    def save(self, report: AnalysisReport) -> None:
        if report.request_id in self._store:
            self._store[report.request_id] = report
            return
        if len(self._order) >= self._max_size:
            oldest = self._order.pop(0)
            self._store.pop(oldest, None)
        self._store[report.request_id] = report
        self._order.append(report.request_id)

    def get(self, request_id: str) -> AnalysisReport | None:
        return self._store.get(request_id)

    def delete(self, request_id: str) -> bool:
        if request_id in self._store:
            self._store.pop(request_id)
            self._order.remove(request_id)
            return True
        return False

    def list_recent(self, limit: int = 20) -> list[dict]:
        recent = self._order[-limit:][::-1]
        return [
            {
                "request_id":  r,
                "gate":        self._store[r].gate_decision.value,
                "risk":        self._store[r].final_risk.value,
                "repo":        self._store[r].repo_url,
                "completed_at": self._store[r].completed_at.isoformat(),
            }
            for r in recent if r in self._store
        ]


# ── Redis backend ─────────────────────────────────────────────────────────────

class RedisReportStore:

    _KEY_PREFIX  = "impact_report:"
    _INDEX_KEY   = "impact_report_index"

    def __init__(self, redis_url: str, ttl: int = DEFAULT_TTL) -> None:
        if not HAS_REDIS:
            raise ImportError("pip install redis to enable Redis report store")
        self._r   = redis_client.from_url(redis_url, decode_responses=True)
        self._ttl = ttl

    def save(self, report: AnalysisReport) -> None:
        key  = f"{self._KEY_PREFIX}{report.request_id}"
        data = report.model_dump_json()
        pipe = self._r.pipeline()
        pipe.set(key, data, ex=self._ttl)
        pipe.zadd(self._INDEX_KEY, {report.request_id: report.completed_at.timestamp()})
        pipe.execute()

    def get(self, request_id: str) -> AnalysisReport | None:
        data = self._r.get(f"{self._KEY_PREFIX}{request_id}")
        if not data:
            return None
        try:
            return AnalysisReport.model_validate_json(data)
        except Exception as e:
            log.error("Failed to deserialise report %s: %s", request_id, e)
            return None

    def delete(self, request_id: str) -> bool:
        pipe = self._r.pipeline()
        pipe.delete(f"{self._KEY_PREFIX}{request_id}")
        pipe.zrem(self._INDEX_KEY, request_id)
        results = pipe.execute()
        return bool(results[0])

    def list_recent(self, limit: int = 20) -> list[dict]:
        ids = self._r.zrevrange(self._INDEX_KEY, 0, limit - 1)
        summaries = []
        for rid in ids:
            report = self.get(rid)
            if report:
                summaries.append({
                    "request_id":  rid,
                    "gate":        report.gate_decision.value,
                    "risk":        report.final_risk.value,
                    "repo":        report.repo_url,
                    "completed_at": report.completed_at.isoformat(),
                })
        return summaries


# ── Factory ────────────────────────────────────────────────────────────────────

def make_report_store(settings=None) -> ReportStore:
    from config.settings import get_settings
    cfg = settings or get_settings()
    if cfg.redis_url and HAS_REDIS:
        try:
            store = RedisReportStore(cfg.redis_url)
            store._r.ping()   # verify connection NOW — if this raises, use in-memory
            log.info("Using Redis report store")
            return store
        except Exception as e:
            log.warning("Redis unavailable (%s) — using in-memory store", e)
    return InMemoryReportStore()
