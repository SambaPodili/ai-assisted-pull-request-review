"""
core/orchestrator.py
---------------------
Central coordinator: wires all agents together for all three phases.

Execution order:
  Phase 1:  code_analysis + security  (parallel)
  Phase 2:  + dependency + test_coverage + interface  (parallel) → risk
  Phase 3:  + remediation  (sequential, always last)

Two execution backends:
  1. LangGraph  — preferred if installed (typed StateGraph, async-ready)
  2. ThreadPoolExecutor — synchronous fallback (no extra deps)
"""
from __future__ import annotations
import asyncio
import logging
import uuid
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Any, Optional

from core.models import (
    AnalysisRequest, AnalysisReport, ChangeType,
    AgentName, AgentTokenUsage,
)
from core.token_manager import TokenBudgetManager
from agents.code_analysis_agent import CodeAnalysisAgent
from agents.security_agent      import SecurityReviewAgent
from agents.dependency_agent    import DependencyMappingAgent
from agents.test_coverage_agent import TestCoverageAgent
from agents.interface_agent     import InterfaceAnalysisAgent
from agents.risk_agent          import RiskAssessmentAgent, build_partial_report_context
from agents.remediation_agent   import RemediationAgent,   build_full_report_context
# Advanced detection agents
from agents.ast_analysis_agent     import ASTAnalysisAgent
from agents.secrets_entropy_agent  import SecretsEntropyAgent
from agents.taint_analysis_agent   import TaintAnalysisAgent
from agents.iac_analysis_agent     import IaCAnalysisAgent
from agents.temporal_risk_agent    import TemporalRiskAgent
from governance.audit_logger    import make_audit_logger, NullAuditLogger
from governance.circuit_breaker import get_breaker_registry, BreakerState
from governance.diff_cache      import get_diff_cache
from context.context_engine     import ContextEngine

log = logging.getLogger(__name__)

try:
    from langgraph.graph import StateGraph, END
    HAS_LANGGRAPH = True
except ImportError:
    HAS_LANGGRAPH = False
    log.info("langgraph not installed — using ThreadPoolExecutor pipeline")


class ImpactAnalysisOrchestrator:
    """
    Top-level coordinator for the AI impact analysis framework.

    Parameters
    ----------
    api_key        : Anthropic API key (or set ANTHROPIC_API_KEY env var)
    phase          : 1 = code+security only
                     2 = + dependency+tests+interface+risk
                     3 = + remediation
    token_budgets  : Override default per-agent allocations
    context_engine : Pre-configured ContextEngine; built from settings if None
    graph_store    : Pre-built dependency graph for DependencyMappingAgent
    """

    def __init__(
        self,
        api_key:        str | None      = None,
        phase:          int             = 2,
        token_budgets:  dict[str, int]  | None = None,
        context_engine: ContextEngine   | None = None,
        graph_store:    Any             | None = None,
    ) -> None:
        self.phase         = phase
        self._budgets      = token_budgets
        self._ctx_engine   = context_engine
        self._audit        = make_audit_logger()

        # Agent instances
        self._code  = CodeAnalysisAgent(api_key)
        self._sec   = SecurityReviewAgent(api_key)
        self._dep   = DependencyMappingAgent(api_key, service_graph=graph_store)
        self._test  = TestCoverageAgent(api_key)
        self._iface = InterfaceAnalysisAgent(api_key)
        self._risk  = RiskAssessmentAgent(api_key)
        self._rem   = RemediationAgent(api_key)
        # Advanced detection agents
        self._ast      = ASTAnalysisAgent(api_key)
        self._entropy  = SecretsEntropyAgent(api_key)
        self._taint    = TaintAnalysisAgent(api_key)
        self._iac      = IaCAnalysisAgent(api_key)
        self._temporal = TemporalRiskAgent(api_key)

    # ── Public API ────────────────────────────────────────────────────────────

    def analyse(self, request: AnalysisRequest) -> AnalysisReport:
        """Synchronous entry point. Returns completed AnalysisReport."""
        # Check diff cache — wrapped in try/except so a cache failure
        # never kills the analysis pipeline
        try:
            cache = get_diff_cache()
            cached = cache.get(request)
            if cached:
                log.info("[%s] Cache HIT — returning cached report", request.request_id)
                return cached
        except Exception as e:
            log.warning("[%s] Cache lookup failed (%s) — running fresh analysis", request.request_id, e)
            cache = None

        if HAS_LANGGRAPH:
            report = self._langgraph_pipeline(request)
        else:
            report = self._threaded_pipeline(request)

        # Store in cache for future identical requests
        try:
            if cache:
                cache.set(request, report)
        except Exception as e:
            log.warning("[%s] Cache write failed (%s) — continuing", request.request_id, e)

        return report

    async def analyse_async(self, request: AnalysisRequest) -> AnalysisReport:
        """Async wrapper for FastAPI / asyncio usage."""
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, self.analyse, request)

    # ═════════════════════════════════════════════════════════════════════════
    #  Threaded pipeline (fallback, no LangGraph dependency)
    # ═════════════════════════════════════════════════════════════════════════

    def _threaded_pipeline(self, request: AnalysisRequest) -> AnalysisReport:
        budget = TokenBudgetManager(request.request_id, self._budgets)
        ctx    = self._build_all_context(request)

        self._audit.log_analysis_started(
            request.request_id, request.repo_url, request.source_ref, request.target_ref
        )
        log.info("[%s] Phase %d analysis started: %s → %s",
                 request.request_id, self.phase, request.source_ref, request.target_ref)

        report = AnalysisReport(
            request_id=request.request_id,
            change_type=request.change_type,
            repo_url=request.repo_url,
            source_ref=request.source_ref,
            target_ref=request.target_ref,
            phase_run=self.phase,
        )

        # ── Phase 1: code_analysis + security (parallel) ──────────────────────
        p1 = self._run_parallel({
            AgentName.CODE_ANALYSIS: (self._code, ctx.get(AgentName.CODE_ANALYSIS, {})),
            AgentName.SECURITY:      (self._sec,  ctx.get(AgentName.SECURITY, {})),
        }, request, budget)

        report.code_analysis = p1.get(AgentName.CODE_ANALYSIS)
        report.security      = p1.get(AgentName.SECURITY)
        self._record_usage(report, p1, AgentName.CODE_ANALYSIS, AgentName.SECURITY)

        # ── Phase 1b: Advanced detection (parallel, always runs) ──────────────
        p1b = self._run_parallel_advanced(request, budget, ctx)
        report.ast_analysis    = p1b.get("ast")
        report.secrets_entropy = p1b.get("entropy")
        report.taint_analysis  = p1b.get("taint")
        report.iac_analysis    = p1b.get("iac")
        report.temporal_risk   = p1b.get("temporal")
        # Record token usage for advanced agents
        for result, name in [(report.ast_analysis, "ast"), (report.secrets_entropy, "entropy"),
                              (report.taint_analysis, "taint")]:
            if result and result.token_usage:
                report.token_usage.append(AgentTokenUsage(
                    agent=AgentName.CODE_ANALYSIS,
                    tokens_used=result.token_usage,
                    model=result.model_used,
                ))

        if self.phase < 2:
            return self._finalize(report, budget)

        # ── Phase 2: dependency + test_coverage + interface (parallel) ────────
        p2 = self._run_parallel({
            AgentName.DEPENDENCY:    (self._dep,   ctx.get(AgentName.DEPENDENCY, {})),
            AgentName.TEST_COVERAGE: (self._test,  ctx.get(AgentName.TEST_COVERAGE, {})),
            AgentName.INTERFACE:     (self._iface, ctx.get(AgentName.INTERFACE, {})),
        }, request, budget)

        report.dependency    = p2.get(AgentName.DEPENDENCY)
        report.test_coverage = p2.get(AgentName.TEST_COVERAGE)
        report.interface     = p2.get(AgentName.INTERFACE)
        self._record_usage(report, p2, AgentName.DEPENDENCY, AgentName.TEST_COVERAGE, AgentName.INTERFACE)

        # Donate unused dependency budget to risk (risk benefits from more context)
        budget.donate_unused("dependency", "risk")

        # ── Risk (sequential — needs all previous results) ────────────────────
        risk_ctx = build_partial_report_context(report)
        report.risk = self._risk.run(request, budget, risk_ctx)
        self._record_single(report, report.risk, AgentName.RISK)

        if self.phase < 3:
            return self._finalize(report, budget)

        # ── Phase 3: remediation (always last) ───────────────────────────────
        rem_ctx = build_full_report_context(report)
        report.remediation = self._rem.run(request, budget, rem_ctx)
        self._record_single(report, report.remediation, AgentName.REMEDIATION)

        return self._finalize(report, budget)

    # ═════════════════════════════════════════════════════════════════════════
    #  LangGraph pipeline — separate state key per agent (no parallel conflict)
    # ═════════════════════════════════════════════════════════════════════════

    def _langgraph_pipeline(self, request: AnalysisRequest) -> AnalysisReport:
        """
        LangGraph pipeline with one state key per agent result.

        LangGraph forbids multiple nodes writing to the same key in the same
        step (parallel fan-out). Using separate keys avoids InvalidUpdateError.
        If LangGraph raises for any reason, falls back to _threaded_pipeline.
        """
        try:
            return self._langgraph_pipeline_inner(request)
        except Exception as exc:
            log.warning(
                "[%s] LangGraph pipeline failed (%s) — falling back to threaded pipeline",
                request.request_id, exc,
            )
            return self._threaded_pipeline(request)

    def _langgraph_pipeline_inner(self, request: AnalysisRequest) -> AnalysisReport:
        from typing import TypedDict

        # ── State with ONE key per agent result ───────────────────────────────
        # This is the correct LangGraph pattern: parallel nodes must each write
        # to their own key; merging happens in the downstream sequential node.
        class PipelineState(TypedDict):
            request:       AnalysisRequest
            budget:        TokenBudgetManager
            context:       dict
            # Per-agent result slots (None = agent not yet run)
            res_code:      Optional[Any]
            res_security:  Optional[Any]
            res_dep:       Optional[Any]
            res_test:      Optional[Any]
            res_iface:     Optional[Any]
            res_risk:      Optional[Any]
            res_rem:       Optional[Any]

        orch = self

        def node_code(state: PipelineState) -> dict:
            ctx = state["context"].get(AgentName.CODE_ANALYSIS, {})
            return {"res_code": orch._code.run(state["request"], state["budget"], ctx)}

        def node_security(state: PipelineState) -> dict:
            ctx = state["context"].get(AgentName.SECURITY, {})
            return {"res_security": orch._sec.run(state["request"], state["budget"], ctx)}

        def node_dependency(state: PipelineState) -> dict:
            ctx = state["context"].get(AgentName.DEPENDENCY, {})
            return {"res_dep": orch._dep.run(state["request"], state["budget"], ctx)}

        def node_test(state: PipelineState) -> dict:
            ctx = state["context"].get(AgentName.TEST_COVERAGE, {})
            return {"res_test": orch._test.run(state["request"], state["budget"], ctx)}

        def node_interface(state: PipelineState) -> dict:
            ctx = state["context"].get(AgentName.INTERFACE, {})
            return {"res_iface": orch._iface.run(state["request"], state["budget"], ctx)}

        def node_risk(state: PipelineState) -> dict:
            # Assemble partial report from per-agent slots then run risk
            partial = AnalysisReport(
                request_id=state["request"].request_id,
                change_type=state["request"].change_type,
                repo_url=state["request"].repo_url,
                source_ref=state["request"].source_ref,
                target_ref=state["request"].target_ref,
                code_analysis=state.get("res_code"),
                security=state.get("res_security"),
                dependency=state.get("res_dep"),
                test_coverage=state.get("res_test"),
                interface=state.get("res_iface"),
            )
            state["budget"].donate_unused("dependency", "risk")
            ctx = build_partial_report_context(partial)
            return {"res_risk": orch._risk.run(state["request"], state["budget"], ctx)}

        def node_remediation(state: PipelineState) -> dict:
            full = AnalysisReport(
                request_id=state["request"].request_id,
                change_type=state["request"].change_type,
                repo_url=state["request"].repo_url,
                source_ref=state["request"].source_ref,
                target_ref=state["request"].target_ref,
                code_analysis=state.get("res_code"),
                security=state.get("res_security"),
                dependency=state.get("res_dep"),
                test_coverage=state.get("res_test"),
                interface=state.get("res_iface"),
                risk=state.get("res_risk"),
            )
            ctx = build_full_report_context(full)
            return {"res_rem": orch._rem.run(state["request"], state["budget"], ctx)}

        # ── Build the graph ───────────────────────────────────────────────────
        builder = StateGraph(PipelineState)
        builder.add_node("code",      node_code)
        builder.add_node("security",  node_security)

        if self.phase >= 2:
            builder.add_node("dependency", node_dependency)
            builder.add_node("test",       node_test)
            builder.add_node("interface",  node_interface)
            builder.add_node("risk",       node_risk)

        if self.phase >= 3:
            builder.add_node("remediation", node_remediation)

        builder.set_entry_point("code")
        builder.add_edge("code", "security")

        if self.phase >= 2:
            # Fan-out: each parallel node writes its own key → no conflict
            builder.add_edge("security",   "dependency")
            builder.add_edge("security",   "test")
            builder.add_edge("security",   "interface")
            # Fan-in: risk waits for all three
            builder.add_edge("dependency", "risk")
            builder.add_edge("test",       "risk")
            builder.add_edge("interface",  "risk")
            if self.phase >= 3:
                builder.add_edge("risk", "remediation")
                builder.add_edge("remediation", END)
            else:
                builder.add_edge("risk", END)
        else:
            builder.add_edge("security", END)

        graph  = builder.compile()
        budget = TokenBudgetManager(request.request_id, self._budgets)
        ctx    = self._build_all_context(request)

        self._audit.log_analysis_started(
            request.request_id, request.repo_url, request.source_ref, request.target_ref
        )

        final = graph.invoke({
            "request":      request,
            "budget":       budget,
            "context":      ctx,
            "res_code":     None,
            "res_security": None,
            "res_dep":      None,
            "res_test":     None,
            "res_iface":    None,
            "res_risk":     None,
            "res_rem":      None,
        })

        # Assemble final AnalysisReport from per-agent slots
        report = AnalysisReport(
            request_id=request.request_id,
            change_type=request.change_type,
            repo_url=request.repo_url,
            source_ref=request.source_ref,
            target_ref=request.target_ref,
            phase_run=self.phase,
            code_analysis=final.get("res_code"),
            security=final.get("res_security"),
            dependency=final.get("res_dep"),
            test_coverage=final.get("res_test"),
            interface=final.get("res_iface"),
            risk=final.get("res_risk"),
            remediation=final.get("res_rem"),
        )
        # Record token usage from each agent result
        for name, slot in [
            (AgentName.CODE_ANALYSIS, "res_code"),
            (AgentName.SECURITY,      "res_security"),
            (AgentName.DEPENDENCY,    "res_dep"),
            (AgentName.TEST_COVERAGE, "res_test"),
            (AgentName.INTERFACE,     "res_iface"),
            (AgentName.RISK,          "res_risk"),
            (AgentName.REMEDIATION,   "res_rem"),
        ]:
            result = final.get(slot)
            if result and getattr(result, "token_usage", 0):
                report.token_usage.append(AgentTokenUsage(
                    agent=name, tokens_used=result.token_usage, model=result.model_used
                ))

        return self._finalize(report, budget)

    # ── Helpers ───────────────────────────────────────────────────────────────

    def _run_parallel_advanced(
        self,
        request: AnalysisRequest,
        budget:  TokenBudgetManager,
        ctx:     dict,
    ) -> dict:
        """
        Run all 5 advanced detection agents in parallel.
        These are deterministic (zero/minimal LLM tokens) so they run fast.
        """
        results: dict[str, Any] = {}
        agents_map = {
            "ast":      self._ast,
            "entropy":  self._entropy,
            "taint":    self._taint,
            "iac":      self._iac,
            "temporal": self._temporal,
        }
        with ThreadPoolExecutor(max_workers=5) as pool:
            futures = {
                pool.submit(agent.run, request, budget, ctx): name
                for name, agent in agents_map.items()
            }
            for future in as_completed(futures):
                name = futures[future]
                try:
                    results[name] = future.result()
                except Exception as exc:
                    log.warning("Advanced agent %s raised: %s", name, exc)
        return results

    def _build_all_context(self, request: AnalysisRequest) -> dict[AgentName, dict]:
        base = {}
        # Per-request model config override (from UI model selection)
        if request.model_config_:
            base["model_config"] = request.model_config_

        if self._ctx_engine:
            per_agent = self._ctx_engine.build_all(request)
            # Merge model_config into every agent context
            if base:
                for k in per_agent:
                    per_agent[k].update(base)
            return per_agent

        # No context engine — return model_config dict for every agent
        if base:
            from core.models import AgentName as AN
            return {agent: dict(base) for agent in AN}
        return {}

    def _run_parallel(
        self,
        agents:  dict[AgentName, tuple],
        request: AnalysisRequest,
        budget:  TokenBudgetManager,
    ) -> dict[AgentName, Any]:
        results: dict[AgentName, Any] = {}
        breakers = get_breaker_registry()

        with ThreadPoolExecutor(max_workers=len(agents)) as pool:
            futures = {}
            for name, (agent, ctx) in agents.items():
                breaker = breakers.get(name.value)
                if not breaker.allow_request():
                    log.warning("[%s] %s circuit breaker OPEN — using fallback", request.request_id, name.value)
                    results[name] = agent.fallback_result(request)
                    results[name].fallback_used = True
                    continue
                futures[pool.submit(agent.run, request, budget, ctx)] = (name, agent, breaker)

            for future in as_completed(futures):
                name, agent, breaker = futures[future]
                try:
                    result = future.result()
                    breaker.record_success()
                    results[name] = result
                except Exception as exc:
                    breaker.record_failure()
                    log.error("[%s] Agent %s raised: %s", request.request_id, name, exc)
                    self._audit.log_agent_error(request.request_id, name.value, str(exc))
                    results[name] = agent.fallback_result(request)
        return results

    def _finalize(self, report: AnalysisReport, budget: TokenBudgetManager) -> AnalysisReport:
        summary = budget.summary()
        report.token_budget = summary["total_allocated"]
        self._audit.log_analysis_completed(
            report.request_id,
            report.gate_decision.value,
            report.final_risk.value,
            report.total_tokens,
        )
        log.info(
            "[%s] Complete. Gate=%s Risk=%s Tokens=%d/%d",
            report.request_id,
            report.gate_decision.value,
            report.final_risk.value,
            report.total_tokens,
            report.token_budget,
        )
        return report

    @staticmethod
    def _record_usage(report: AnalysisReport, results: dict, *names: AgentName) -> None:
        for name in names:
            r = results.get(name)
            if r and r.token_usage:
                report.token_usage.append(AgentTokenUsage(
                    agent=name, tokens_used=r.token_usage, model=r.model_used
                ))

    @staticmethod
    def _record_single(report: AnalysisReport, result: Any, name: AgentName) -> None:
        if result and result.token_usage:
            report.token_usage.append(AgentTokenUsage(
                agent=name, tokens_used=result.token_usage, model=result.model_used
            ))