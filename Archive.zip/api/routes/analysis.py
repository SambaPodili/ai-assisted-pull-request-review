"""
api/routes/analysis.py
-----------------------
REST endpoints for direct analysis submission and report retrieval.
"""
from __future__ import annotations
import logging
import uuid
from datetime import datetime
from typing import Any

from fastapi import APIRouter, BackgroundTasks, HTTPException
from pydantic import BaseModel

from core.models import (
    AnalysisRequest, AnalysisReport, ChangeType,
    GateDecision, RiskLevel,
)
from ingestion.diff_parser import parse_diff
from output.report_formatter import to_summary_json, to_markdown

log = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1", tags=["analysis"])

# In-flight request tracker: request_id → status string
_in_flight: dict[str, str] = {}


class AnalyseRequest(BaseModel):
    repo_url:     str
    source_ref:   str
    target_ref:   str
    change_type:  ChangeType = ChangeType.BRANCH
    diff_text:    str = ""
    metadata:     dict[str, Any] = {}
    llm_config:   dict[str, Any] = {}   # per-request LLM override (avoids Pydantic reserved name)
    # Accept legacy field name too
    model_config_override: dict[str, Any] = {}  # alias for llm_config


@router.post("/analyse", status_code=202)
async def submit_analysis(payload: AnalyseRequest, background: BackgroundTasks):
    """
    Submit a code diff for asynchronous analysis.
    Returns immediately with a request_id; poll /report/{id} for results.
    Also returns status via GET /api/v1/status/{id}.
    """
    from api.app import get_orchestrator, get_report_store
    orch  = get_orchestrator()
    store = get_report_store()

    request_id = str(uuid.uuid4())
    hunks      = parse_diff(payload.diff_text) if payload.diff_text else []

    # Merge llm_config and model_config_override (accept both field names)
    llm_cfg = payload.llm_config or payload.model_config_override or {}

    req = AnalysisRequest(
        request_id=request_id,
        change_type=payload.change_type,
        repo_url=payload.repo_url,
        source_ref=payload.source_ref,
        target_ref=payload.target_ref,
        hunks=hunks,
        metadata=payload.metadata,
        model_config_=llm_cfg,
    )

    _in_flight[request_id] = "running"

    async def _run():
        try:
            report = await orch.analyse_async(req)
            store.save(report)
            _in_flight[request_id] = "done"
            log.info("[%s] Analysis complete — gate=%s", request_id, report.gate_decision.value)
        except Exception as exc:
            log.error("[%s] Analysis failed: %s", request_id, exc, exc_info=True)
            _in_flight[request_id] = f"error: {exc}"
            # Save an error report so the frontend gets something back
            # rather than polling 404 forever
            error_report = AnalysisReport(
                request_id=request_id,
                change_type=req.change_type,
                repo_url=req.repo_url,
                source_ref=req.source_ref,
                target_ref=req.target_ref,
                errors=[str(exc)],
            )
            try:
                store.save(error_report)
            except Exception as save_exc:
                log.error("[%s] Could not save error report: %s", request_id, save_exc)

    background.add_task(_run)
    return {"request_id": request_id, "status": "queued"}


@router.get("/status/{request_id}")
def get_status(request_id: str):
    """Quick status check — useful to poll before fetching the full report."""
    status = _in_flight.get(request_id)
    if status is None:
        return {"request_id": request_id, "status": "unknown"}
    return {"request_id": request_id, "status": status}


@router.get("/report/{request_id}")
def get_report(request_id: str, fmt: str = "json"):
    """
    Retrieve a completed analysis report.
    fmt=json  → compact summary JSON (default)
    fmt=full  → full JSON with all agent results
    fmt=md    → Markdown report
    Returns 202 while still processing (not 404).
    """
    from api.app import get_report_store
    store  = get_report_store()

    # If still running, return 202 so the frontend knows to keep polling
    status = _in_flight.get(request_id)
    if status == "running":
        raise HTTPException(202, detail="Analysis still running — please poll again shortly.")

    report = store.get(request_id)
    if not report:
        raise HTTPException(404, detail=f"Report '{request_id}' not found.")

    if fmt == "md":
        return {"markdown": to_markdown(report)}
    if fmt == "full":
        return report.model_dump()
    return to_summary_json(report)


@router.get("/reports")
def list_reports(limit: int = 20):
    """List the most recent analysis reports."""
    from api.app import get_report_store
    return get_report_store().list_recent(limit=min(limit, 100))


@router.delete("/report/{request_id}", status_code=204)
def delete_report(request_id: str):
    from api.app import get_report_store
    deleted = get_report_store().delete(request_id)
    if not deleted:
        raise HTTPException(404, detail=f"Report '{request_id}' not found.")