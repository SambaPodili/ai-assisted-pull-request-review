"""
api/middleware/auth.py
-----------------------
API key authentication middleware.
Skipped automatically when SKIP_AUTH=true (development mode).

IMPORTANT: OPTIONS requests (CORS preflight) must always be allowed through
without auth — the browser sends these before every cross-origin request and
they never carry credentials. Blocking them causes "Failed to fetch" errors.
"""
from __future__ import annotations
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import JSONResponse


class APIKeyMiddleware(BaseHTTPMiddleware):

    _OPEN_PATHS = {"/health", "/docs", "/openapi.json", "/redoc", "/metrics"}

    def __init__(self, app, api_keys: list[str], skip_auth: bool = False) -> None:
        super().__init__(app)
        self._keys      = set(api_keys)
        self._skip_auth = skip_auth

    async def dispatch(self, request: Request, call_next):
        # Always allow CORS preflight through — browsers send OPTIONS before
        # every cross-origin request; these never carry auth headers
        if request.method == "OPTIONS":
            return await call_next(request)

        if self._skip_auth or request.url.path in self._OPEN_PATHS:
            return await call_next(request)

        key = (
            request.headers.get("X-API-Key")
            or request.headers.get("Authorization", "").removeprefix("Bearer ").strip()
        )
        if not key or key not in self._keys:
            return JSONResponse(
                {"error": "Unauthorized — provide X-API-Key header"},
                status_code=401,
            )

        return await call_next(request)
