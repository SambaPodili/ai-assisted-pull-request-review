"""
governance/review_session_store.py
-----------------------------------
Persistent developer → reviewer → PR review workflow ("continuity").

A REVIEW SESSION is keyed by request_id and moves through three stages:

  developer  — the author triages each finding: valid / false_positive / wont_fix
               + a free-text comment. When done they SUBMIT for review.
  reviewer   — a user with the REVIEWER role sees the developer's triage and
               validates each finding: confirmed / rejected + a comment, then
               FINALIZES (final gate decision).
  done       — only findings the developer marked VALID *and* the reviewer
               CONFIRMED are the "real issues" — those get posted back to the PR.

Everything is persisted (SQLite) so the developer can key comments, hand off, and
a different reviewer can pick it up later — true continuity across people/sessions.

Backend: SQLite (single file). Degrades to a no-op store if SQLite is unavailable.
"""
from __future__ import annotations

import logging
import sqlite3
from datetime import datetime, timezone
from pathlib import Path

log = logging.getLogger(__name__)
DEFAULT_DB_PATH = "data/review_sessions.db"

STAGES = ("developer", "reviewer", "done")
_DEV_VERDICTS = {"", "valid", "false_positive", "wont_fix"}
_REV_VERDICTS = {"", "confirmed", "rejected"}


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


class SQLiteReviewSessionStore:
    def __init__(self, db_path: str = DEFAULT_DB_PATH) -> None:
        Path(db_path).parent.mkdir(parents=True, exist_ok=True)
        self._path = db_path
        self._conn = sqlite3.connect(db_path, check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        self._init_schema()

    def _init_schema(self) -> None:
        self._conn.executescript("""
            CREATE TABLE IF NOT EXISTS review_session (
                request_id    TEXT PRIMARY KEY,
                repo          TEXT DEFAULT '',
                pr_id         TEXT DEFAULT '',
                stage         TEXT DEFAULT 'developer',   -- developer | reviewer | done
                final_gate    TEXT DEFAULT '',
                posted_to_pr  INTEGER DEFAULT 0,
                submitted_by  TEXT DEFAULT '',
                finalized_by  TEXT DEFAULT '',
                created_at    TEXT NOT NULL,
                updated_at    TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS review_triage (
                request_id        TEXT NOT NULL,
                finding_key       TEXT NOT NULL,
                title             TEXT DEFAULT '',
                agent             TEXT DEFAULT '',
                file              TEXT DEFAULT '',
                line              TEXT DEFAULT '',
                severity          TEXT DEFAULT '',
                dev_verdict       TEXT DEFAULT '',
                dev_comment       TEXT DEFAULT '',
                dev_by            TEXT DEFAULT '',
                dev_ts            TEXT DEFAULT '',
                reviewer_verdict  TEXT DEFAULT '',
                reviewer_comment  TEXT DEFAULT '',
                reviewer_by       TEXT DEFAULT '',
                reviewer_ts       TEXT DEFAULT '',
                PRIMARY KEY (request_id, finding_key)
            );
            CREATE INDEX IF NOT EXISTS idx_rt_req ON review_triage(request_id);
            CREATE TABLE IF NOT EXISTS pr_comment_map (
                provider      TEXT NOT NULL,
                repo_slug     TEXT NOT NULL,
                pr_id         TEXT NOT NULL,
                comment_id    TEXT NOT NULL,
                request_id    TEXT NOT NULL,
                finding_key   TEXT DEFAULT '',
                file_path     TEXT DEFAULT '',
                line          TEXT DEFAULT '',
                created_at    TEXT NOT NULL,
                PRIMARY KEY (provider, repo_slug, pr_id, comment_id)
            );
            CREATE INDEX IF NOT EXISTS idx_pcm_req ON pr_comment_map(request_id);
            CREATE TABLE IF NOT EXISTS pr_reply_log (
                provider      TEXT NOT NULL,
                repo_slug     TEXT NOT NULL,
                pr_id         TEXT NOT NULL,
                author        TEXT DEFAULT '',
                reply_comment_id TEXT DEFAULT '',
                blocked       INTEGER DEFAULT 0,   -- 1 = prompt_guard rejected, no LLM call made
                created_at    TEXT NOT NULL
            );
            CREATE INDEX IF NOT EXISTS idx_prl_rate
                ON pr_reply_log(provider, repo_slug, pr_id, author, created_at);
            CREATE TABLE IF NOT EXISTS pr_analysis_head (
                provider      TEXT NOT NULL,
                repo_slug     TEXT NOT NULL,
                pr_id         TEXT NOT NULL,
                head_sha      TEXT DEFAULT '',
                request_id    TEXT DEFAULT '',
                analyzed_at   TEXT NOT NULL,
                PRIMARY KEY (provider, repo_slug, pr_id)
            );
        """)
        self._conn.commit()

    # ── PR comment correlation (interactive chat replies) ───────────────────────

    def record_posted_comment(self, provider: str, repo_slug: str, pr_id: str, comment_id: str,
                               request_id: str, finding_key: str = "", file_path: str = "",
                               line: str = "") -> None:
        """Called right after the bot successfully posts an inline finding
        comment — the only way a later reply's in_reply_to_id can ever be
        resolved back to a finding/report."""
        self._conn.execute(
            "INSERT OR REPLACE INTO pr_comment_map "
            "(provider, repo_slug, pr_id, comment_id, request_id, finding_key, file_path, line, created_at) "
            "VALUES (?,?,?,?,?,?,?,?,?)",
            (provider, repo_slug, pr_id, str(comment_id), request_id, finding_key, file_path, line, _now()),
        )
        self._conn.commit()

    def lookup_comment(self, provider: str, repo_slug: str, pr_id: str, comment_id: str) -> dict | None:
        row = self._conn.execute(
            "SELECT * FROM pr_comment_map WHERE provider=? AND repo_slug=? AND pr_id=? AND comment_id=?",
            (provider, repo_slug, pr_id, str(comment_id)),
        ).fetchone()
        return dict(row) if row else None

    def latest_comment_for_pr(self, provider: str, repo_slug: str, pr_id: str) -> dict | None:
        """Most recently posted comment for this PR — the fallback used when
        a reply has no in_reply_to_id (a top-level comment addressing the bot
        generally, not threaded to a specific finding)."""
        row = self._conn.execute(
            "SELECT * FROM pr_comment_map WHERE provider=? AND repo_slug=? AND pr_id=? "
            "ORDER BY created_at DESC LIMIT 1",
            (provider, repo_slug, pr_id),
        ).fetchone()
        return dict(row) if row else None

    def log_reply(self, provider: str, repo_slug: str, pr_id: str, author: str,
                   reply_comment_id: str = "", blocked: bool = False) -> None:
        """Audit-only record of an auto-answered (or guard-blocked) reply —
        never mutates review_session/review_triage or the report itself."""
        self._conn.execute(
            "INSERT INTO pr_reply_log (provider, repo_slug, pr_id, author, reply_comment_id, blocked, created_at) "
            "VALUES (?,?,?,?,?,?,?)",
            (provider, repo_slug, pr_id, author, reply_comment_id, int(blocked), _now()),
        )
        self._conn.commit()

    def count_recent_replies(self, provider: str, repo_slug: str, pr_id: str, author: str,
                              window_seconds: int) -> int:
        """Replies logged for this (PR, author) within the last `window_seconds`
        — the rate-limit check in governance/reply_answerer.py."""
        cutoff = datetime.now(timezone.utc).timestamp() - window_seconds
        rows = self._conn.execute(
            "SELECT created_at FROM pr_reply_log WHERE provider=? AND repo_slug=? AND pr_id=? AND author=?",
            (provider, repo_slug, pr_id, author),
        ).fetchall()
        count = 0
        for r in rows:
            try:
                ts = datetime.fromisoformat(r["created_at"]).timestamp()
                if ts >= cutoff:
                    count += 1
            except ValueError:
                continue
        return count

    # ── Triage carry-forward across re-analyses ─────────────────────────────────

    def carry_forward_triage(self, old_request_id: str, new_request_id: str, new_top_issues: list) -> int:
        """Copies matching review_triage verdicts from a PR's prior analysis
        onto its new one. review_triage is keyed only by request_id
        (governance/review_session_store.py's own schema) with no PR-level
        lookup — a reviewer's false_positive/won't_fix verdict on the old
        request_id is otherwise silently invisible once a new push creates a
        new request_id, on EVERY re-analysis (not just incremental ones).
        Matching is by finding_key, a Python port of the client's own
        triageKey formula (frontend/src/views/ResultsView.jsx:653) — must
        stay byte-for-byte identical, since the web app's triage UI reads/
        writes this same key format:
            f"{agent or 'issue'}|{file_path or ''}|{line or ''}|{title[:60]}"
        (line uses JS `line || ''` falsy-zero semantics: line=0 -> '', not
        '0' — Python's `line or ''` matches this exactly for ints.)
        Returns the number of verdicts carried forward."""
        old_rows = {r["finding_key"]: r for r in self.list_triage(old_request_id)}
        if not old_rows:
            return 0

        carried = 0
        for issue in new_top_issues:
            agent = (issue.agents[0] if getattr(issue, "agents", None) else None) or "issue"
            key = f"{agent}|{issue.file_path or ''}|{issue.line or ''}|{(issue.title or '')[:60]}"
            old = old_rows.get(key)
            if not old or not (old.get("dev_verdict") or old.get("reviewer_verdict")):
                continue
            self._conn.execute(
                """INSERT OR IGNORE INTO review_triage
                   (request_id, finding_key, title, agent, file, line, severity,
                    dev_verdict, dev_comment, dev_by, dev_ts,
                    reviewer_verdict, reviewer_comment, reviewer_by, reviewer_ts)
                   VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (new_request_id, key, old.get("title", ""), old.get("agent", ""),
                 old.get("file", ""), old.get("line", ""), old.get("severity", ""),
                 old.get("dev_verdict", ""), old.get("dev_comment", ""), old.get("dev_by", ""), old.get("dev_ts", ""),
                 old.get("reviewer_verdict", ""), old.get("reviewer_comment", ""), old.get("reviewer_by", ""), old.get("reviewer_ts", "")),
            )
            carried += 1
        if carried:
            self._conn.commit()
        return carried

    # ── Incremental re-analysis v1 (skip on trivial pushes) ─────────────────────

    def record_pr_head(self, provider: str, repo_slug: str, pr_id: str, head_sha: str, request_id: str) -> None:
        """Called after a real (first-time or full) analysis completes for a
        webhook-triggered PR — remembers what was analyzed so the next push
        can tell whether anything actually changed."""
        self._conn.execute(
            "INSERT OR REPLACE INTO pr_analysis_head "
            "(provider, repo_slug, pr_id, head_sha, request_id, analyzed_at) VALUES (?,?,?,?,?,?)",
            (provider, repo_slug, pr_id, head_sha, request_id, _now()),
        )
        self._conn.commit()

    def get_last_analyzed_head(self, provider: str, repo_slug: str, pr_id: str) -> dict | None:
        row = self._conn.execute(
            "SELECT head_sha, request_id FROM pr_analysis_head WHERE provider=? AND repo_slug=? AND pr_id=?",
            (provider, repo_slug, pr_id),
        ).fetchone()
        return dict(row) if row else None

    # ── Session ───────────────────────────────────────────────────────────────

    def ensure_session(self, request_id: str, repo: str = "", pr_id: str = "") -> dict:
        row = self._conn.execute("SELECT * FROM review_session WHERE request_id=?",
                                  (request_id,)).fetchone()
        if row is None:
            now = _now()
            self._conn.execute(
                """INSERT INTO review_session (request_id, repo, pr_id, stage, created_at, updated_at)
                   VALUES (?,?,?,?,?,?)""",
                (request_id, repo, pr_id, "developer", now, now),
            )
            self._conn.commit()
        elif (repo and not row["repo"]) or (pr_id and not row["pr_id"]):
            self._conn.execute(
                "UPDATE review_session SET repo=COALESCE(NULLIF(?,''),repo), pr_id=COALESCE(NULLIF(?,''),pr_id), updated_at=? WHERE request_id=?",
                (repo, pr_id, _now(), request_id))
            self._conn.commit()
        return self.get_session(request_id)

    def get_session(self, request_id: str) -> dict | None:
        row = self._conn.execute("SELECT * FROM review_session WHERE request_id=?",
                                  (request_id,)).fetchone()
        if row is None:
            return None
        s = dict(row)
        s["posted_to_pr"] = bool(s.get("posted_to_pr"))
        s["triage"] = self.list_triage(request_id)
        return s

    def list_triage(self, request_id: str) -> list[dict]:
        rows = self._conn.execute(
            "SELECT * FROM review_triage WHERE request_id=? ORDER BY rowid", (request_id,)).fetchall()
        return [dict(r) for r in rows]

    # ── Triage ────────────────────────────────────────────────────────────────

    def set_triage(self, request_id: str, finding_key: str, role: str, verdict: str,
                   comment: str, by: str, meta: dict | None = None) -> dict:
        """Upsert the developer OR reviewer columns of a finding's triage row."""
        if role not in ("developer", "reviewer"):
            raise ValueError("role must be developer or reviewer")
        if role == "developer" and verdict not in _DEV_VERDICTS:
            raise ValueError(f"dev verdict must be one of {_DEV_VERDICTS}")
        if role == "reviewer" and verdict not in _REV_VERDICTS:
            raise ValueError(f"reviewer verdict must be one of {_REV_VERDICTS}")

        self.ensure_session(request_id, (meta or {}).get("repo", ""), (meta or {}).get("pr_id", ""))
        m = meta or {}
        # create the row (with metadata) if absent
        self._conn.execute(
            """INSERT OR IGNORE INTO review_triage
               (request_id, finding_key, title, agent, file, line, severity)
               VALUES (?,?,?,?,?,?,?)""",
            (request_id, finding_key, m.get("title", ""), m.get("agent", ""),
             m.get("file", ""), str(m.get("line", "")), m.get("severity", "")),
        )
        now = _now()
        if role == "developer":
            self._conn.execute(
                "UPDATE review_triage SET dev_verdict=?, dev_comment=?, dev_by=?, dev_ts=? WHERE request_id=? AND finding_key=?",
                (verdict, comment, by, now, request_id, finding_key))
        else:
            self._conn.execute(
                "UPDATE review_triage SET reviewer_verdict=?, reviewer_comment=?, reviewer_by=?, reviewer_ts=? WHERE request_id=? AND finding_key=?",
                (verdict, comment, by, now, request_id, finding_key))
        self._touch(request_id)
        self._conn.commit()
        return dict(self._conn.execute(
            "SELECT * FROM review_triage WHERE request_id=? AND finding_key=?",
            (request_id, finding_key)).fetchone())

    # ── Stage transitions ─────────────────────────────────────────────────────

    def submit(self, request_id: str, by: str) -> dict:
        """Developer hands off → reviewer stage."""
        self.ensure_session(request_id)
        self._conn.execute(
            "UPDATE review_session SET stage='reviewer', submitted_by=?, updated_at=? WHERE request_id=?",
            (by, _now(), request_id))
        self._conn.commit()
        return self.get_session(request_id)

    def reopen(self, request_id: str, by: str) -> dict:
        """Reviewer sends it back to the developer."""
        self.ensure_session(request_id)
        self._conn.execute(
            "UPDATE review_session SET stage='developer', updated_at=? WHERE request_id=?",
            (_now(), request_id))
        self._conn.commit()
        return self.get_session(request_id)

    def finalize(self, request_id: str, gate: str, by: str, posted: bool = False) -> dict:
        """Reviewer finalizes → done stage, records the gate + whether issues posted."""
        self.ensure_session(request_id)
        self._conn.execute(
            "UPDATE review_session SET stage='done', final_gate=?, finalized_by=?, posted_to_pr=?, updated_at=? WHERE request_id=?",
            (gate, by, 1 if posted else 0, _now(), request_id))
        self._conn.commit()
        return self.get_session(request_id)

    # ── The "real issues" to post: dev VALID ∩ reviewer CONFIRMED ──────────────

    def validated_findings(self, request_id: str) -> list[dict]:
        rows = self.list_triage(request_id)
        return [r for r in rows
                if r.get("dev_verdict") == "valid" and r.get("reviewer_verdict") == "confirmed"]

    def _touch(self, request_id: str) -> None:
        self._conn.execute("UPDATE review_session SET updated_at=? WHERE request_id=?",
                           (_now(), request_id))


class _NullReviewSessionStore:
    def ensure_session(self, *a, **k): return None
    def get_session(self, *a, **k): return None
    def list_triage(self, *a, **k): return []
    def set_triage(self, *a, **k): return {}
    def submit(self, *a, **k): return None
    def reopen(self, *a, **k): return None
    def finalize(self, *a, **k): return None
    def validated_findings(self, *a, **k): return []
    def record_posted_comment(self, *a, **k): return None
    def lookup_comment(self, *a, **k): return None
    def latest_comment_for_pr(self, *a, **k): return None
    def log_reply(self, *a, **k): return None
    def count_recent_replies(self, *a, **k): return 0
    def record_pr_head(self, *a, **k): return None
    def get_last_analyzed_head(self, *a, **k): return None
    def carry_forward_triage(self, *a, **k): return 0


_store = None


def get_review_store():
    global _store
    if _store is None:
        try:
            from config.settings import get_settings
            _cfg = get_settings()
            path = getattr(_cfg, "review_session_db_path", "") or _cfg.data_path("review_sessions.db")
            _store = SQLiteReviewSessionStore(path)
            log.info("Review-session store: SQLite (%s)", path)
        except Exception as exc:
            log.warning("Review-session store unavailable (%s) — using no-op", exc)
            _store = _NullReviewSessionStore()
    return _store
